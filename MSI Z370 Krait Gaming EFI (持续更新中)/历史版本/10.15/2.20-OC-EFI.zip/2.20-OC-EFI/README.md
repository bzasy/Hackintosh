### 我的配置   
CPU I7-8700K  
主板 MSI Z370 Krait Gaming (银环蛇)  
内存 CORSAIR 海盗船 DDR4 3000  
显卡 蓝宝石 RX580 超白8G  
SMBIOS 19.1  

## 特别注意  
需在BIOS关闭CFG LOCK（MSR 0xe2寄存器）默认开启   
需自己生成SMBIOS，已经抹掉SN  
非银环蛇主板使用此EFI很可能会卡开机  
SMBIOS已清除，请自行配置！！！！！！！！

### 目前工作正常  
声卡  
网卡  
USB  
变频  
接力  
隔空播放  
硬件加速（已注入FCPX加速ID）  
睡眠  

### 更新变化  
更新OpenCore到0.5.6


### 目前存在的问题  
未知  

### 最后  
不推荐直接套用，只可借鉴
